package com.example.zakatgoldcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button button,btnAbout;

    private EditText weightInput, valueInput;
    private RadioGroup typeRadioGroup;
    private RadioButton radioKeep, radioWear;
    private Button calculateButton;
    private TextView outputLabel, totalZakatLabel;

    // Variable to keep track of total Zakat amount
    private double totalZakatAmount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAbout = findViewById(R.id.aboutButton);

        button = findViewById(R.id.button);
        button.setOnClickListener(this);

        weightInput = findViewById(R.id.weightInput);
        typeRadioGroup = findViewById(R.id.typeRadioGroup);
        radioKeep = findViewById(R.id.radioKeep);
        radioWear = findViewById(R.id.radioWear);
        valueInput = findViewById(R.id.valueInput);
        calculateButton = findViewById(R.id.calculateButton);
        outputLabel = findViewById(R.id.outputLabel);
        totalZakatLabel = findViewById(R.id.totalZakatLabel);

        totalZakatAmount = 0.0;

        calculateButton.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                calculateZakat();

            }
        });

    }

    private void calculateZakat() {
        try {
            double weight = Double.parseDouble(weightInput.getText().toString());

            // Validate the selected gold type before proceeding with calculations
            String goldType;
            if (radioKeep.isChecked()) {
                goldType = "keep";
            } else if (radioWear.isChecked()) {
                goldType = "wear";
            } else {
                outputLabel.setText("Error: Please select a gold type.");
                return;
            }

            double valuePerGram = Double.parseDouble(valueInput.getText().toString());
            double xGrams = (goldType.equals("keep")) ? 85 : 200;

            double totalValue = weight * valuePerGram;
            double zakatPayableValue = (weight - xGrams) * valuePerGram;
            double zakatAmount = 0.025 * zakatPayableValue;

            // Add the current Zakat amount to the total
            totalZakatAmount += zakatAmount;

            String resultText = String.format("Total Value of Gold: %.2f\n", totalValue);
            resultText += String.format("Total Gold Value That is Zakat Payable: %.2f\n", zakatPayableValue);
            resultText += String.format("Current Zakat: %.2f\n", zakatAmount);
            resultText += String.format("Total Zakat: %.2f", totalZakatAmount);

            outputLabel.setText(resultText);
            totalZakatLabel.setText(String.format("Total Zakat: %.2f", totalZakatAmount));
        } catch (NumberFormatException e) {
            outputLabel.setText("Error: Invalid input. Please enter valid numbers.");
        }
    }

    @Override
    public void onClick(View v) {
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, "https://github.com.my");
        sendIntent.setType("text/plain");
        sendIntent.putExtra(Intent.EXTRA_TITLE,"GITHUB FOR THIS APPLICATION");

        Intent shareIntent = Intent.createChooser(sendIntent, null);
        startActivity(shareIntent);

    }

    public void openAboutActivity(View view) {
        Intent intent = new Intent(this, AboutActivity.class);
        startActivity(intent);
    }
}